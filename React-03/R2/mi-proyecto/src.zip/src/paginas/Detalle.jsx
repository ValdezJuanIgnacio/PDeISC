import React from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { Card } from 'react-bootstrap';

function Detalle({ tareas }) {
  const { id } = useParams();
  const tarea = tareas.find(t => t.id === parseInt(id));

  if (!tarea) {
    return <Navigate to="/" replace />;
  }

  return (
    <Card className="mb-3">
      <Card.Body>
        <Card.Title>{tarea.titulo}</Card.Title>
        <Card.Text>
          <strong>Descripción:</strong> {tarea.descripcion}
        </Card.Text>
        <Card.Text>
          {}
          {tarea.fechaCreacion && (
            <span>
              <strong>Fecha de creación:</strong> {tarea.fechaCreacion}
            </span>
          )}
        </Card.Text>
        <Card.Text>
          <strong>Estado:</strong> {tarea.estado === 'completa' ? 'Completa' : 'Incompleta'}
        </Card.Text>
      </Card.Body>
    </Card>
  );
}

export default Detalle;
import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Container, Navbar, Nav, Button } from 'react-bootstrap';
import Inicio from './paginas/Inicio.jsx';
import Detalle from './paginas/Detalle.jsx';
import Crear from './paginas/Crear.jsx';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const [tareas, setTareas] = useState([
    {
      id: 1,
      titulo: 'Comprar pan',
      descripcion: 'Ir a la panadería a las 8am',
      estado: 'completa',
      fechaCreacion: new Date().toLocaleString()
    },
    {
      id: 2,
      titulo: 'Hacer ejercicio',
      descripcion: 'Correr 30 minutos',
      estado: 'incompleta',
      fechaCreacion: new Date().toLocaleString()
    }
  ]);

  const crearTarea = (nuevaTarea) => {
    const id = tareas.length > 0 ? Math.max(...tareas.map(t => t.id)) + 1 : 1;
    setTareas([...tareas, { id, ...nuevaTarea }]);
  };

  const descargarTareas = () => {

    const dataStr = JSON.stringify(tareas, null, 2);

    const blob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);


    const link = document.createElement("a");
    link.href = url;
    link.download = "tareas.json";


    document.body.appendChild(link);
    link.click();


    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <Router>
      <Navbar bg="dark" variant="dark" expand="lg">
        <Container>
          <Navbar.Brand as={Link} to="/">Mis Tareas</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link as={Link} to="/">Inicio</Nav.Link>
            <Nav.Link as={Link} to="/crear">Nueva Tarea</Nav.Link>
            {}
            <Button variant="outline-light" className="ms-3" onClick={descargarTareas}>
              Descargar Tareas
            </Button>
          </Nav>
        </Container>
      </Navbar>

      <Container className="mt-4">
        <Routes>
          <Route path="/" element={<Inicio tareas={tareas} />} />
          <Route path="/detalle/:id" element={<Detalle tareas={tareas} />} />
          <Route path="/crear" element={<Crear onCrearTarea={crearTarea} />} />
        </Routes>
      </Container>
    </Router>
  );
}

export default App;
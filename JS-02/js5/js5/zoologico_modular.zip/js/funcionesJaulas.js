function crearJaulas() {
  cantidadJaulas = parseInt(document.getElementById("inputJaulas").value);
  const selectJaulas = document.getElementById("jaula");
  selectJaulas.innerHTML = "";
  for (let i = 1; i <= cantidadJaulas; i++) {
    let option = new Option("Jaula " + i, i);
    selectJaulas.appendChild(option);
  }
}

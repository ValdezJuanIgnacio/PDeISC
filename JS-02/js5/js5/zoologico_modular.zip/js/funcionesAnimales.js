document.getElementById("formAnimal").addEventListener("submit", function (e) {
  e.preventDefault();
  const animal = new CZooAnimal(
    document.getElementById("idAnimal").value,
    document.getElementById("nombre").value,
    parseInt(document.getElementById("jaula").value),
    parseInt(document.getElementById("tipoAnimal").value),
    parseFloat(document.getElementById("peso").value)
  );
  zoo.push(animal);
  this.reset();
  renderTabla();
});

function renderTabla() {
  let html = `<table class="table table-bordered mt-3"><thead><tr>
    <th>ID</th><th>Nombre</th><th>Jaula</th><th>Tipo</th><th>Peso (kg)</th>
  </tr></thead><tbody>`;
  zoo.forEach(animal => {
    html += `<tr>
      <td>${animal.IdAnimal}</td><td>${animal.nombre}</td>
      <td>${animal.JaulaNumero}</td><td>${tiposAnimales[animal.IdTypeAnimal]}</td>
      <td>${animal.peso}</td>
    </tr>`;
  });
  html += "</tbody></table>";
  document.getElementById("tablaAnimales").innerHTML = html;
}

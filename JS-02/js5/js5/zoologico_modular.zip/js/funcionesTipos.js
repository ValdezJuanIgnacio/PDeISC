function agregarTipo() {
  const nuevo = document.getElementById("nuevoTipo").value.trim();
  if (nuevo && !tiposAnimales.includes(nuevo)) {
    tiposAnimales.push(nuevo);
    renderTipos();
    document.getElementById("nuevoTipo").value = "";
  }
}

function renderTipos() {
  const selectTipo = document.getElementById("tipoAnimal");
  const filtroTipo = document.getElementById("tipoFiltro");
  selectTipo.innerHTML = "";
  filtroTipo.innerHTML = "";
  tiposAnimales.forEach((tipo, index) => {
    let opt = new Option(tipo, index);
    selectTipo.appendChild(opt);
    filtroTipo.appendChild(opt.cloneNode(true));
  });
}

let zoo = [];
let tiposAnimales = ["Felino", "Ave", "Reptil"];
let cantidadJaulas = 0;

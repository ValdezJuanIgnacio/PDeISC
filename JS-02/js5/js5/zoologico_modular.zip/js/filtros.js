function filtrarAnimalesPeso() {
  const jaula = parseInt(document.getElementById("jaulaFiltro1").value);
  const peso = parseFloat(document.getElementById("pesoFiltro1").value);
  const cantidad = zoo.filter(z => z.JaulaNumero === jaula && z.peso < peso).length;
  alert(`Cantidad: ${cantidad}`);
}

function filtrarTipoYJaula() {
  const tipo = parseInt(document.getElementById("tipoFiltro").value);
  const desde = parseInt(document.getElementById("jaulaDesde").value);
  const hasta = parseInt(document.getElementById("jaulaHasta").value);
  const cantidad = zoo.filter(z => z.IdTypeAnimal === tipo && z.JaulaNumero >= desde && z.JaulaNumero <= hasta).length;
  alert(`Cantidad: ${cantidad}`);
}

function animalMenorPeso() {
  const jaula = parseInt(document.getElementById("jaulaFiltro2").value);
  const peso = parseFloat(document.getElementById("pesoFiltro2").value);
  const animal = zoo.find(z => z.JaulaNumero === jaula && z.peso < peso);
  alert(animal ? `Encontrado: ${animal.nombre}` : "No encontrado");
}
